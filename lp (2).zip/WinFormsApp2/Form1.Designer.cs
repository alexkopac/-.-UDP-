﻿
namespace WinFormsApp2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            disconnectBtn = new Button();
            connectBtn = new Button();
            sendBtn = new Button();
            updataBtn = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            SuspendLayout();
            // 
            // disconnectBtn
            // 
            disconnectBtn.Font = new Font("Segoe UI", 21F);
            disconnectBtn.Location = new Point(13, 274);
            disconnectBtn.Name = "disconnectBtn";
            disconnectBtn.Size = new Size(282, 44);
            disconnectBtn.TabIndex = 0;
            disconnectBtn.Text = "Відключитись";
            disconnectBtn.UseVisualStyleBackColor = true;
            disconnectBtn.Click += disconnectBtn_Click;
            // 
            // connectBtn
            // 
            connectBtn.Font = new Font("Segoe UI", 21F);
            connectBtn.Location = new Point(12, 165);
            connectBtn.Name = "connectBtn";
            connectBtn.Size = new Size(282, 51);
            connectBtn.TabIndex = 1;
            connectBtn.Text = "Приєднатись";
            connectBtn.UseVisualStyleBackColor = true;
            connectBtn.Click += connectBtn_Click;
            // 
            // sendBtn
            // 
            sendBtn.Font = new Font("Segoe UI", 21F);
            sendBtn.Location = new Point(12, 223);
            sendBtn.Name = "sendBtn";
            sendBtn.Size = new Size(128, 45);
            sendBtn.TabIndex = 2;
            sendBtn.Text = "Відправити";
            sendBtn.UseVisualStyleBackColor = true;
            sendBtn.Click += sendBtn_Click;
            // 
            // updataBtn
            // 
            updataBtn.Font = new Font("Segoe UI", 21F);
            updataBtn.Location = new Point(147, 223);
            updataBtn.Name = "updataBtn";
            updataBtn.Size = new Size(148, 45);
            updataBtn.TabIndex = 3;
            updataBtn.Text = "Оновити";
            updataBtn.UseVisualStyleBackColor = true;
            updataBtn.Click += updataBtn_Click;
            // 
            // textBox1
            // 
            textBox1.BorderStyle = BorderStyle.FixedSingle;
            textBox1.Font = new Font("Segoe UI", 21F);
            textBox1.Location = new Point(12, 63);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(282, 45);
            textBox1.TabIndex = 4;
            // 
            // textBox2
            // 
            textBox2.BorderStyle = BorderStyle.FixedSingle;
            textBox2.Font = new Font("Segoe UI", 21F);
            textBox2.ForeColor = SystemColors.InactiveBorder;
            textBox2.Location = new Point(12, 12);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(282, 45);
            textBox2.TabIndex = 5;
            // 
            // textBox3
            // 
            textBox3.BorderStyle = BorderStyle.FixedSingle;
            textBox3.Font = new Font("Segoe UI", 21F);
            textBox3.Location = new Point(12, 114);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(283, 45);
            textBox3.TabIndex = 6;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(307, 329);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(updataBtn);
            Controls.Add(sendBtn);
            Controls.Add(connectBtn);
            Controls.Add(disconnectBtn);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button disconnectBtn;
        private Button connectBtn;
        private Button sendBtn;
        private Button updataBtn;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
    }
}
