﻿namespace Serv
{
    internal class ProgramBase
    {
    }
}